param(
    [string]$Python,
    [int[]]$RowGroups = @(8192, 32768),
    [int]$Repeats = 5,
    [string]$OutputDir,
    [string]$KeepParquet,
    [switch]$Coastal,
    [switch]$HotStations,
    [double]$BudgetMiB = 1.5,
    [switch]$CompareDensity
)

$ErrorActionPreference = 'Stop'
if ($Coastal -and $HotStations) { throw 'Choose either -Coastal or -HotStations.' }
if ($CompareDensity -and -not $HotStations) { throw '-CompareDensity requires -HotStations.' }
if (-not $Python) {
    $bundledPython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
    if (Test-Path -LiteralPath $bundledPython) {
        $Python = $bundledPython
    } else {
        $pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
        if (-not $pythonCommand -or $pythonCommand.Source -like '*\Microsoft\WindowsApps\*') {
            throw 'Install Python 3.10+ or specify -Python with the full path to python.exe.'
        }
        $Python = $pythonCommand.Source
    }
}

$pythonTag = & $Python -c "import sys, platform; assert sys.version_info >= (3, 10); print(sys.implementation.cache_tag + '-' + platform.machine().lower())"
if ($LASTEXITCODE -ne 0) { throw 'Python 3.10 or later is required.' }

$packages = Join-Path $env:TEMP "parquet-sorting-lab-deps-$pythonTag"
$existingCache = Join-Path $env:USERPROFILE 'AppData/Local/Temp/parquet-sorting-lab-deps'
if ($pythonTag -eq 'cpython-312-amd64' -and (Test-Path -LiteralPath $existingCache)) {
    $packages = $existingCache
}

$previousPythonPath = $env:PYTHONPATH
try {
    $env:PYTHONPATH = (@($packages, $previousPythonPath) | Where-Object { $_ }) -join [IO.Path]::PathSeparator
    $check = "import duckdb, fsspec; print(duckdb.__version__ == '1.5.0' and fsspec.__version__ == '2025.7.0')"
    $ready = & $Python -c "import importlib.util as u; print(bool(u.find_spec('duckdb') and u.find_spec('fsspec')))"
    if ($ready -ne 'True' -or (& $Python -c $check) -ne 'True') {
        & $Python -m pip install --disable-pip-version-check --upgrade --target $packages -r (Join-Path $PSScriptRoot 'requirements.txt')
        if ($LASTEXITCODE -ne 0) { throw 'Could not install the Python requirements.' }
    }

    if ($HotStations) {
        $script = 'hot_station_case.py'
        $experimentArgs = @('--budget-mib', $BudgetMiB.ToString([CultureInfo]::InvariantCulture))
        if ($CompareDensity) { $experimentArgs += '--compare-density' }
    } elseif ($Coastal) {
        $script = 'coastal_case.py'
        $experimentArgs = @('--repeats', $Repeats)
    } else {
        $script = 'experiment.py'
        $experimentArgs = @('--repeats', $Repeats, '--row-groups') + $RowGroups
        if ($KeepParquet) { $experimentArgs += @('--keep-parquet', $KeepParquet) }
    }
    if ($OutputDir) { $experimentArgs += @('--output-dir', $OutputDir) }
    & $Python (Join-Path $PSScriptRoot $script) @experimentArgs
    if ($LASTEXITCODE -ne 0) { throw 'The experiment did not finish. See the Python error above.' }
} finally {
    $env:PYTHONPATH = $previousPythonPath
}
