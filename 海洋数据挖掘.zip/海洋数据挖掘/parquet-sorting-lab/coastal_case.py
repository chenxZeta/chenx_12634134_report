"""Replay storm briefings and annual buoy audits on the local NOAA archive."""

import argparse
import csv
import random
import statistics
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import duckdb

from experiment import ROOT, SCHEMA, SEED, MeteredFiles, build_csv, literal


REGION = (41001, 41009, 41010, 42001)
STORMS = (("Ian", "2022-09-27"), ("Idalia", "2023-08-29"), ("Debby", "2024-08-04"))
WEIGHTS = {"brief": 0.75, "audit": 0.25}
ROW_GROUP = 8192
PARQUET_ORDERS = {
    "archive_order": "source_row",
    "time": "obs_time, station_id, source_row",
    "station": "station_id, obs_time, source_row",
    "month_time": "obs_time, station_id, source_row",
}


@dataclass(frozen=True)
class Request:
    key: str
    storm: str
    kind: str
    start: datetime
    stop: datetime
    stations: tuple[int, ...]

    @property
    def split(self):
        return "holdout" if self.start.year == 2024 else "calibration"

    def select(self, source):
        stations = ", ".join(map(str, self.stations))
        return f"""
            SELECT station_id, count(*) AS reports, count(wave_m) AS wave_reports,
                   max(wave_m) AS max_wave_m
            FROM {source}
            WHERE station_id IN ({stations})
              AND obs_time >= {literal(self.start)} AND obs_time < {literal(self.stop)}
            GROUP BY station_id
            ORDER BY station_id
        """


def requests():
    result = []
    for storm, date in STORMS:
        start = datetime.fromisoformat(date)
        for index in range(3):
            first = start + timedelta(days=2 * index)
            result.append(Request(
                f"{storm}-brief-{index + 1}", storm, "brief", first,
                first + timedelta(days=2), REGION,
            ))
        for station in REGION:
            first = datetime(start.year, 1, 1)
            result.append(Request(
                f"{storm}-audit-{station}", storm, "audit", first,
                datetime(start.year + 1, 1, 1), (station,),
            ))
    return result


def month_after(first):
    return datetime(first.year + (first.month == 12), first.month % 12 + 1, 1)


def selected_months(start, stop):
    month = datetime(start.year, start.month, 1)
    while month < stop:
        yield month.strftime("%Y-%m")
        month = month_after(month)


def csv_scan(path):
    columns = ", ".join(f"'{name}': '{kind}'" for name, kind in (
        definition.strip().split() for definition in SCHEMA.split(",")
    ))
    return f"read_csv({literal(path)}, columns={{{columns}}}, auto_detect=false, header=true)"


def build_layouts(db, directory, archive_csv, parquet_orders=None):
    layouts = {"csv": {"all": archive_csv}}
    write_ms = {}
    orders = PARQUET_ORDERS if parquet_orders is None else parquet_orders
    for layout, order in orders.items():
        start = time.perf_counter()
        files = {}
        if layout == "month_time":
            months = selected_months(datetime(2022, 1, 1), datetime(2025, 1, 1))
        else:
            months = ("all",)
        for month in months:
            file = directory / f"{layout}-{month}.parquet"
            where = ""
            if month != "all":
                first = datetime.fromisoformat(month + "-01")
                where = f"WHERE obs_time >= {literal(first)} AND obs_time < {literal(month_after(first))}"
            db.execute(f"""
                COPY (SELECT * EXCLUDE (source_row) FROM archive {where} ORDER BY {order})
                TO {literal(file)}
                (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE {ROW_GROUP},
                 WRITE_BLOOM_FILTER false)
            """)
            files[month] = file
        layouts[layout] = files
        write_ms[layout] = round(1000 * (time.perf_counter() - start), 2)
    return layouts, write_ms


def reader(layout, files, metered):
    paths = [f"buoylab://{file.name}" if metered else file for file in files]
    if layout == "csv":
        return csv_scan(paths[0])
    return "read_parquet([" + ", ".join(map(literal, paths)) + "])"


def measure(db, layouts, workload, repeats):
    meter = MeteredFiles(file for files in layouts.values() for file in files.values())
    db.register_filesystem(meter)
    measured, answers, tasks = [], [], []
    for request in workload:
        expected = db.execute(request.select("archive")).fetchall()
        answer_by_station = {station: (total, wave, peak) for station, total, wave, peak in expected}
        for station in request.stations:
            total, wave, peak = answer_by_station.get(station, (0, 0, None))
            answers.append({
                "split": request.split, "case": request.key, "kind": request.kind,
                "start_utc_inclusive": request.start, "end_utc_exclusive": request.stop,
                "station": station, "received_records": total, "valid_wave_records": wave,
                "received_records_without_wave": total - wave,
                "max_reported_significant_wave_height_m": None if peak is None else round(peak, 2),
            })
        for layout, files in layouts.items():
            selected = list(files.values())
            if layout == "month_time":
                selected = [files[month] for month in selected_months(request.start, request.stop)]
            meter.bytes_read = 0
            observed = db.execute(request.select(reader(layout, selected, True))).fetchall()
            read_bytes = meter.bytes_read
            native_sql = request.select(reader(layout, selected, False))
            warm = db.execute(native_sql).fetchall()
            if observed != expected or warm != expected or read_bytes <= 0:
                raise RuntimeError(f"Result mismatch for {request.key} using {layout}")
            measured.append({
                "split": request.split, "case": request.key, "kind": request.kind,
                "layout": layout, "files_selected": len(selected), "read_bytes": read_bytes,
            })
            tasks.append(native_sql)

    times = [[] for _ in tasks]
    order = list(range(len(tasks)))
    sampler = random.Random(SEED)
    for _ in range(repeats):
        sampler.shuffle(order)
        for index in order:
            start = time.perf_counter_ns()
            db.execute(tasks[index]).fetchall()
            times[index].append((time.perf_counter_ns() - start) / 1_000_000)
    for record, samples in zip(measured, times):
        record["median_warm_ms"] = round(statistics.median(samples), 4)
    return measured, answers


def summarize(layouts, write_ms, measured):
    def average(split, kind, layout, metric):
        return statistics.mean(
            row[metric] for row in measured
            if (row["split"], row["kind"], row["layout"]) == (split, kind, layout)
        )

    def cost(routes, split, metric):
        return sum(weight * average(split, kind, routes[kind], metric) for kind, weight in WEIGHTS.items())

    methods = {layout: {kind: layout for kind in WEIGHTS} for layout in layouts}
    # Pick routes on Ian + Idalia, before scoring any Debby or 2024 audit query.
    methods["workload_route"] = {
        kind: min(PARQUET_ORDERS, key=lambda layout: average("calibration", kind, layout, "read_bytes"))
        for kind in WEIGHTS
    }
    result = []
    for method, routes in methods.items():
        copies = set(routes.values())
        stored_files = [file for copy in copies for file in layouts[copy].values()]
        result.append({
            "method": method,
            "brief_layout": routes["brief"], "audit_layout": routes["audit"],
            "brief_weight": WEIGHTS["brief"], "audit_weight": WEIGHTS["audit"],
            "calibration_weighted_KiB": round(cost(routes, "calibration", "read_bytes") / 1024, 2),
            "holdout_brief_KiB": round(average("holdout", "brief", routes["brief"], "read_bytes") / 1024, 2),
            "holdout_audit_KiB": round(average("holdout", "audit", routes["audit"], "read_bytes") / 1024, 2),
            "holdout_weighted_KiB": round(cost(routes, "holdout", "read_bytes") / 1024, 2),
            "holdout_weighted_warm_ms": round(cost(routes, "holdout", "median_warm_ms"), 3),
            "files": len(stored_files),
            "storage_MiB": round(sum(file.stat().st_size for file in stored_files) / 1048576, 3),
            "parquet_build_ms": round(sum(write_ms.get(copy, 0) for copy in copies), 2) if method != "csv" else "",
        })
    return result


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "coastal-results")
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("repeats must be at least 1")

    with tempfile.TemporaryDirectory(prefix="coastal-buoy-") as temp:
        directory = Path(temp)
        archive_csv = directory / "observations.csv"
        manifest = build_csv(ROOT / "data" / "ndbc", archive_csv)
        with duckdb.connect(config={"threads": 1, "enable_external_file_cache": False}) as db:
            db.execute("LOAD parquet")
            db.execute("SET parquet_metadata_cache = false")
            db.execute("SET preserve_insertion_order = true")
            db.execute(f"CREATE TABLE archive AS SELECT row_number() OVER () AS source_row, * FROM {csv_scan(archive_csv)}")
            count = db.execute("SELECT COUNT(*) FROM archive").fetchone()[0]
            if count != sum(file["rows"] for file in manifest):
                raise RuntimeError("Source record count mismatch")
            print(f"Loaded {count:,} real NOAA records. Building CSV and four Parquet layouts.", flush=True)
            layouts, write_ms = build_layouts(db, directory, archive_csv)
            workload = requests()
            measured, answers = measure(db, layouts, workload, args.repeats)
            summary = summarize(layouts, write_ms, measured)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "benchmark.csv", measured)
    write_csv(args.output_dir / "methods.csv", summary)
    write_csv(args.output_dir / "wave-reports.csv", answers)
    print(f"Passed {len(measured)} result comparisons. Results: {args.output_dir}", flush=True)


if __name__ == "__main__":
    main()
