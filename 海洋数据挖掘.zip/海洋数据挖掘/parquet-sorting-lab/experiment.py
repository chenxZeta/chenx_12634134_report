"""Build and benchmark the same buoy observations in several Parquet orders."""

import argparse
import csv
import gzip
import hashlib
import io
import json
import platform
import random
import statistics
import tempfile
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.request import urlopen

import duckdb
import fsspec
from fsspec.spec import AbstractFileSystem

ROOT = Path(__file__).resolve().parent
ARCHIVE = "https://www.ndbc.noaa.gov/data/historical/stdmet/"
STATIONS = (41001, 41009, 41010, 42001, 44008, 44011, 46042, 46050)
YEARS = range(2022, 2025)
UNAVAILABLE = (46042, 2024)
SEED = 20261118

LAYOUTS = {
    "shuffle": ("随机基线", "shuffle_key"),
    "station": ("站点", "station_id, shuffle_key"),
    "time": ("时间", "obs_time, shuffle_key"),
    "station_time": ("站点 → 时间", "station_id, obs_time, shuffle_key"),
    "time_station": ("时间 → 站点", "obs_time, station_id, shuffle_key"),
    "sst": ("海表温度", "sst_tenths NULLS LAST, shuffle_key"),
}
KINDS = {
    "station": "单站历史",
    "time": "跨站时间窗",
    "station_time": "单站时间窗",
    "sst": "海温区间",
}
SCHEMA = (
    "station_id INTEGER, obs_time TIMESTAMP, sst_tenths SMALLINT,"
    " wind_mps REAL, wave_m REAL, air_c REAL, pressure_hpa REAL"
)
AGGREGATE = "COUNT(*), COUNT(sst_tenths), SUM(sst_tenths)"


@dataclass(frozen=True)
class Predicate:
    column: str
    low: int | datetime
    high: int | datetime | None = None

    def sql(self):
        if self.high is None:
            return f"{self.column} = {literal(self.low)}"
        return f"{self.column} >= {literal(self.low)} AND {self.column} < {literal(self.high)}"

    def may_match(self, group, rows):
        low, high, nulls, _ = group[self.column]
        if nulls == rows:
            return False
        if low is None or high is None:
            return True
        if self.high is None:
            return low <= self.low <= high
        return high >= self.low and low < self.high


@dataclass(frozen=True)
class Query:
    name: str
    kind: str
    predicates: tuple[Predicate, ...]

    @property
    def where(self):
        return " AND ".join(predicate.sql() for predicate in self.predicates)

    @property
    def columns(self):
        return {"sst_tenths"} | {predicate.column for predicate in self.predicates}

    def select(self, source):
        return f"SELECT {AGGREGATE} FROM {source} WHERE {self.where}"


class MeteredFile(io.FileIO):
    def __init__(self, path, mode, meter):
        super().__init__(path, mode)
        self.meter = meter

    def read(self, size=-1):
        data = super().read(size)
        self.meter.bytes_read += len(data)
        return data

    def readinto(self, buffer):
        size = super().readinto(buffer)
        self.meter.bytes_read += size
        return size


class MeteredFiles(AbstractFileSystem):
    """Expose only the experiment's Parquet files to DuckDB's fsspec reader."""

    protocol = "buoylab"
    cachable = False

    def __init__(self, files):
        super().__init__()
        self.files = {file.name: file for file in files}
        self.bytes_read = 0

    def local_path(self, path):
        name = self._strip_protocol(path)
        try:
            return self.files[name]
        except KeyError as exc:
            raise FileNotFoundError(name) from exc

    def glob(self, path, **kwargs):
        name = self._strip_protocol(path)
        return [name] if name in self.files else []

    def info(self, path, **kwargs):
        file = self.local_path(path)
        return {"name": file.name, "type": "file", "size": file.stat().st_size}

    def modified(self, path):
        return datetime.fromtimestamp(self.local_path(path).stat().st_mtime, timezone.utc)

    def _open(self, path, mode="rb", **kwargs):
        return MeteredFile(self.local_path(path), mode, self)


def literal(value):
    if isinstance(value, datetime):
        return f"TIMESTAMP '{value:%Y-%m-%d %H:%M:%S}'"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Path):
        value = value.as_posix()
    return "'" + value.replace("'", "''") + "'"


def work_queries():
    queries = []
    windows = ("2022-05-01", "2023-02-01", "2023-08-01", "2024-06-01")
    selected = (41009, 42001, 44008, 46050)
    for index, (date, station, sst) in enumerate(
        zip(windows, selected, (150, 200, 250, 270)), start=1
    ):
        start = datetime.fromisoformat(date)
        station_predicate = Predicate("station_id", station)
        time_predicate = Predicate("obs_time", start, start + timedelta(days=14))
        cases = (
            ("station", (station_predicate,)),
            ("time", (time_predicate,)),
            ("station_time", (station_predicate, time_predicate)),
            ("sst", (Predicate("sst_tenths", sst, sst + 10),)),
        )
        queries.extend(Query(f"{kind}_{index}", kind, predicates) for kind, predicates in cases)
    return queries


def number(text, missing):
    if text in {"MM", "NaN"}:
        return None
    value = float(text)
    return None if value == missing else value


def build_csv(directory, target):
    directory.mkdir(parents=True, exist_ok=True)
    manifest = []
    with target.open("w", newline="", encoding="utf-8") as output:
        writer = csv.writer(output)
        writer.writerow(("station_id", "obs_time", "sst_tenths", "wind_mps", "wave_m", "air_c", "pressure_hpa"))
        for station in STATIONS:
            for year in YEARS:
                if (station, year) == UNAVAILABLE:
                    continue
                archive = directory / f"{station}h{year}.txt.gz"
                url = ARCHIVE + archive.name
                if not archive.is_file():
                    print(f"Downloading {archive.name}", flush=True)
                    with urlopen(url, timeout=40) as response:
                        data = response.read()
                    gzip.decompress(data)
                    archive.write_bytes(data)
                count = 0
                with gzip.open(archive, "rt", encoding="ascii") as source:
                    header = source.readline().lstrip("#").split()
                    positions = {key: header.index(key) for key in ("WTMP", "WSPD", "WVHT", "ATMP", "PRES")}
                    for line in source:
                        if not line.strip() or line.startswith("#"):
                            continue
                        fields = line.split()
                        stamp = datetime(*map(int, fields[:5]))
                        sst = number(fields[positions["WTMP"]], 999)
                        writer.writerow((
                            station,
                            stamp.isoformat(sep=" "),
                            None if sst is None else round(sst * 10),
                            number(fields[positions["WSPD"]], 99),
                            number(fields[positions["WVHT"]], 99),
                            number(fields[positions["ATMP"]], 999),
                            number(fields[positions["PRES"]], 9999),
                        ))
                        count += 1
                manifest.append({
                    "file": archive.name, "url": url, "rows": count,
                    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                })
    return manifest


def group_stats(connection, file):
    metadata = connection.execute(
        """SELECT row_group_id, row_group_num_rows, path_in_schema, stats_min_value,
                  stats_max_value, stats_null_count, total_compressed_size, bloom_filter_offset
           FROM parquet_metadata(?) ORDER BY row_group_id, column_id""",
        [str(file)],
    ).fetchall()
    group_rows = {}
    chunks = defaultdict(dict)
    for group_id, rows, column, low, high, nulls, size, bloom in metadata:
        if bloom is not None:
            raise RuntimeError("Unexpected Bloom filter in the control experiment")
        group_rows[group_id] = rows
        parse = datetime.fromisoformat if column == "obs_time" else int
        if column in {"obs_time", "station_id", "sst_tenths"}:
            low = None if low is None else parse(low)
            high = None if high is None else parse(high)
        chunks[group_id][column] = (low, high, nulls, size)
    return [(index, group_rows[index], chunks[index]) for index in chunks]


def benchmark(connection, directory, sizes, repetitions):
    queries = work_queries()
    baseline = {query.name: connection.execute(query.select("observations")).fetchone() for query in queries}
    empty = [name for name, values in baseline.items() if not values[0]]
    if empty:
        raise RuntimeError(f"Empty query windows in source: {empty}")
    files = {}
    for size in sizes:
        for layout, (_, order) in LAYOUTS.items():
            file = directory / f"{layout}-{size}.parquet"
            connection.execute(f"""
                COPY (SELECT * EXCLUDE (shuffle_key) FROM observations ORDER BY {order})
                TO {literal(file)}
                (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE {size}, WRITE_BLOOM_FILTER false)
            """)
            files[size, layout] = file
        print(f"Wrote 6 layouts with row groups of {size:,} rows", flush=True)

    meter = MeteredFiles(files.values())
    connection.register_filesystem(meter)
    results = []
    tasks = []
    for (size, layout), file in files.items():
        groups = group_stats(connection, file)
        if any(rows != size for _, rows, _ in groups[:-1]):
            raise RuntimeError(f"Unexpected row group size in {file.name}")
        for query in queries:
            candidate = [
                (index, rows, chunks) for index, rows, chunks in groups
                if all(predicate.may_match(chunks, rows) for predicate in query.predicates)
            ]
            estimated = sum(
                chunks[column][3] for _, _, chunks in candidate for column in query.columns
            )
            measured_sql = query.select(f"read_parquet('buoylab://{file.name}')")
            native_sql = query.select(f"read_parquet({literal(file)})")
            meter.bytes_read = 0
            measured_result = connection.execute(measured_sql).fetchone()
            measured_bytes = meter.bytes_read
            native_result = connection.execute(native_sql).fetchone()
            expected = baseline[query.name]
            if measured_result != expected or native_result != expected or measured_bytes <= 0 or not candidate:
                raise RuntimeError(f"Validation failed for {file.name}, {query.name}")
            results.append({
                "row_group_size": size, "layout": layout, "query": query.name, "type": query.kind,
                "where_sql": query.where,
                "matches": expected[0], "valid_sst": expected[1], "sum_sst_tenths": expected[2],
                "groups_total": len(groups), "groups_candidate": len(candidate),
                "rows_candidate": sum(rows for _, rows, _ in candidate),
                "groups_skipped_pct": 100 * (1 - len(candidate) / len(groups)),
                "estimated_chunk_bytes": estimated, "reader_bytes": measured_bytes,
                "file_bytes": file.stat().st_size,
                "candidate_ids": [index for index, _, _ in candidate],
            })
            tasks.append(native_sql)

    samples = [[] for _ in tasks]
    sequence = list(range(len(tasks)))
    randomizer = random.Random(SEED)
    for _ in range(repetitions):
        randomizer.shuffle(sequence)
        for index in sequence:
            start = time.perf_counter_ns()
            connection.execute(tasks[index]).fetchone()
            samples[index].append((time.perf_counter_ns() - start) / 1_000_000)
    for result, times in zip(results, samples):
        result["median_ms"] = round(statistics.median(times), 4)
        result["elapsed_ms"] = [round(value, 4) for value in times]
    return results


def write_results(directory, payload):
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "source-manifest.json").write_text(
        json.dumps(payload["sources"], indent=2), encoding="utf-8"
    )
    with (directory / "measurements.csv").open("w", newline="", encoding="utf-8-sig") as output:
        records = payload["results"]
        writer = csv.DictWriter(output, fieldnames=list(records[0]))
        writer.writeheader()
        for record in records:
            writer.writerow({
                key: json.dumps(value, separators=(",", ":")) if isinstance(value, list) else value
                for key, value in record.items()
            })
    template = (ROOT / "dashboard-template.html").read_text(encoding="utf-8")
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    (directory / "dashboard.html").write_text(template.replace("__EXPERIMENT_DATA__", encoded), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data" / "ndbc")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--row-groups", type=int, nargs="+", default=[8192, 32768])
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--keep-parquet", type=Path, help="also keep a copy of each Parquet layout")
    args = parser.parse_args()
    sizes = sorted(set(args.row_groups))
    if any(size < 2048 or size % 2048 for size in sizes) or args.repeats < 1:
        parser.error("row-group sizes must be positive multiples of 2048, and repeats at least 1")

    with tempfile.TemporaryDirectory(prefix="buoy-parquet-") as scratch:
        directory = Path(scratch)
        source = directory / "observations.csv"
        manifest = build_csv(args.data_dir, source)
        with duckdb.connect(config={
            "threads": 1, "preserve_insertion_order": True,
            "enable_external_file_cache": False,
        }) as connection:
            connection.execute("LOAD parquet")
            connection.execute("SET parquet_metadata_cache = false")
            connection.execute(f"CREATE TABLE staging ({SCHEMA})")
            connection.execute(f"COPY staging FROM {literal(source)} (FORMAT CSV, HEADER true)")
            connection.execute(f"""
                CREATE TABLE observations AS
                SELECT *, hash(rowid, {SEED}) AS shuffle_key FROM staging
            """)
            connection.execute("DROP TABLE staging")
            counts = connection.execute("SELECT COUNT(*), COUNT(sst_tenths) FROM observations").fetchone()
            if counts[0] != sum(entry["rows"] for entry in manifest):
                raise RuntimeError("Imported row count differs from the source manifest")
            print(f"Loaded {counts[0]:,} observations from {len(manifest)} archives", flush=True)
            results = benchmark(connection, directory, sizes, args.repeats)
        if args.keep_parquet:
            import shutil
            args.keep_parquet.mkdir(parents=True, exist_ok=True)
            for file in directory.glob("*.parquet"):
                shutil.copyfile(file, args.keep_parquet / file.name)

    write_results(args.output_dir, {
        "counts": counts, "sources": manifest, "results": results, "sizes": sizes,
        "layouts": {key: label for key, (label, _) in LAYOUTS.items()}, "kinds": KINDS,
        "repeats": args.repeats, "duckdb": duckdb.__version__, "fsspec": fsspec.__version__,
        "platform": platform.system(), "seed": SEED,
    })
    print(f"Report: {args.output_dir / 'dashboard.html'}", flush=True)


if __name__ == "__main__":
    main()
