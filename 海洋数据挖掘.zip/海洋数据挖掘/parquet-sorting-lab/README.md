# Parquet 按哪一列排序，才能让查询少读数据

## 研究背景

课件页脚第 4 页介绍列裁剪、谓词下推和数据跳过，第 8 页讨论分区、排序与合并，第 19 页用“站点、时间、几十个传感器变量”的浮标时序表提出布局设计题。本实验固定文件层的其他参数，测量写入顺序如何影响单个 Parquet 文件内部的行组剪枝。

Parquet 把连续的记录分成行组（row group），每组内按列保存列块（column chunk）。读者可按查询所需的列做列裁剪，也可利用列块记录的最小值和最大值排除整个行组。比如查询 5 月 1 日到 15 日（左闭右开）的记录，若某行组的最晚时间仍早于 5 月 1 日，或者最早时间已到 5 月 15 日，就可排除该行组。写入前按时间排序会让连续记录的时间更接近，从而使各行组覆盖的时间区间变窄。[Apache Parquet 格式说明](https://parquet.apache.org/docs/file-format/) · [DuckDB 的 Parquet 列裁剪与谓词下推](https://duckdb.org/docs/1.5/data/parquet/overview)

等值条件 `station_id = s` 保留 min ≤ s ≤ max 的组。区间条件 `a ≤ x < b` 保留 max ≥ a 且 min < b 的组。用 `AND` 连接过滤条件时，任一条件可以排除某组即可跳过。多个条件分别与行组范围重叠时，仍需读取候选行组检验它们是否在同一条记录上满足。纯空值组可以排除，缺失范围统计时保守保留。[DuckDB 的 Parquet 元数据字段](https://duckdb.org/docs/1.5/data/parquet/metadata)

## 数据与对照实验

取 NOAA NDBC 2022–2024 年 8 个浮标站的 23 份年度标准气象档案，共 **1,032,773 行**。站点为 41001、41009、41010、42001、44008、44011、46042、46050。46042 的 2024 年档案在官方下载地址返回 404，因此样本包含其余 23 个站点年。日期和时间按 UTC 解释。数据列包括站点、观测时间、海表温度、风速、浪高、气温和气压。海温按十分之一摄氏度存成整数，缺测标记转换为 NULL。原始压缩文件随实验保存在 `data/ndbc/`，文件名、URL、行数和 SHA-256 见 [源数据清单](results/source-manifest.json)。[NOAA 年度数据下载目录](https://www.ndbc.noaa.gov/data/historical/stdmet/) · [NOAA 字段与单位说明](https://www.ndbc.noaa.gov/faq/measdes.shtml)

| 要素 | 实验设置 |
|---|---|
| 写入顺序 | 固定种子随机基线、站点、时间、站点→时间、时间→站点、海温 |
| 单列排序的平局 | 同一排序键内按固定种子的散列顺序写入，控制并列记录的次序 |
| 行组大小 | 8,192 和 32,768 行，末组可较小 |
| 固定项 | 相同原始记录和数据类型、ZSTD、每种布局一个文件、单线程，禁用 Bloom filter 及 DuckDB 外部文件缓存和 Parquet 元数据缓存 |
| 查询 | 单站历史、跨站 14 天时间窗、单站 14 天时间窗、1 °C 海温区间，各 4 个实例 |
| 正确性检查 | 每条查询比较总命中行数、有效海温数、海温整数之和，和原始表逐项核对 |

每个查询执行下列形式的聚合，具体过滤条件见 [原始测量表](results/measurements.csv)。平均海温为 `SUM(sst_tenths) / COUNT(sst_tenths) / 10`，分母对应有效海温数。

```sql
SELECT COUNT(*), COUNT(sst_tenths), SUM(sst_tenths)
FROM read_parquet('parquet-example/time_station-8192.parquet')
WHERE station_id = 41009
  AND obs_time >= TIMESTAMP '2022-05-01 00:00:00'
  AND obs_time <  TIMESTAMP '2022-05-15 00:00:00';
```

| 记录量 | 计算方法 |
|---|---|
| 候选行组、可跳过比例 | 读取 `parquet_metadata()`，逐行组计算 min/max 与查询条件是否重叠 |
| 候选列块压缩量 | 对候选行组内的过滤列和聚合列累加 `total_compressed_size`，每列只计一次 |
| 实测文件读取量 | DuckDB 通过 fsspec 读取本地 Parquet，累加文件接口每次实际返回的字节数，含页脚、预读及重复读取。该计数也包含被操作系统缓存满足的请求 |
| 查询耗时 | 使用 DuckDB 的原生本地路径。每条预热后运行 5 次，固定随机顺序轮换各查询和布局，取单条查询的中位数 |

## 实验结果

[打开离线交互结果](results/dashboard.html)，可切换行组大小、指标和查询案例。下表采用 8,192 行/组，每行是同类 4 个查询的平均文件读取量。共测量 192 种「布局 × 行组大小 × 查询」组合，全部通过查询结果校验。

| 查询 | 随机基线（KiB） | 读取量最小的布局 | 最小读取量（KiB） | 较基线少读 |
|---|---:|---|---:|---:|
| 单站历史 | 1,746.4 | 站点→时间 | 158.3 | 90.9% |
| 跨站 14 天 | 7,575.4 | 时间→站点 | 138.9 | 98.2% |
| 单站 14 天 | 7,972.5 | 时间→站点 | 139.4 | 98.3% |
| 海温区间 | 1,349.3 | 海温 | 102.7 | 92.4% |

- 在 41009 站 2022 年 5 月 1 日到 15 日的案例中，各布局均命中 2,016 行。随机基线的 127 组均为候选，时间→站点仅保留 3 组。
- 小时间窗使时间优先布局能把候选范围迅速缩到几组。8,192 行/组时，单站 14 天查询平均而言，站点→时间的行组剪枝率为 98.03%，时间→站点为 97.64%。时间→站点的候选列块平均约 36.2 KiB，站点→时间约 74.0 KiB。列块压缩大小随布局变化，因此读取量的最优排序与剪枝率的最优排序可以不同。
- 混合查询可用 `Σ(查询类别的频率 × 该类别的平均读取字节数)` 选布局。例如四类查询等频时，8,192 行/组的最优布局为站点→时间（279.5 KiB/次），32,768 行/组则为时间→站点（311.2 KiB/次）。这些结论适用于本样本、查询窗口、候选排序和测量设置。其他站点密度、时间跨度、压缩方式或查询比例下可用同一方法重测。

## 在电脑上复现

若收到的是 `parquet-sorting-lab.zip`，先解压得到 `parquet-sorting-lab` 文件夹。在项目的上一级目录打开 PowerShell。若已进入项目根目录，从第二行开始运行。脚本需要 Python 3.10 或更新版本，缺少的依赖会按 [requirements.txt](requirements.txt) 安装。随包的 NOAA 数据可离线读取。

```powershell
Set-Location -LiteralPath .\parquet-sorting-lab
.\run.ps1 -KeepParquet .\parquet-example
Start-Process .\results\dashboard.html
```

也可在项目根目录直接运行以下 Python 命令。缺少的 NOAA 档案会从官方链接下载。

```text
python -m pip install -r requirements.txt
python experiment.py --keep-parquet parquet-example
```

修改行组大小、另存图表和保留实验 Parquet 的示例。默认结果仍保存在 `results/`。

```text
python experiment.py --row-groups 4096 16384 --repeats 7 --output-dir results-extra --keep-parquet parquet-extra
```

磁盘上还会短暂生成用于导入的 CSV 和 Parquet 文件。若需改变查询负载，修改 [实验代码](experiment.py) 中的 `work_queries()`。上面的运行命令会把示例 SQL 所用的 Parquet 保留在 `parquet-example/`。生成文件后，在项目根目录使用 DuckDB 执行示例 SQL。

## 风暴复盘与浮标年度检查

[现场案例脚本](coastal_case.py) 用同一批 NOAA 档案模拟沿海监测团队的两项任务。风暴简报按 48 小时窗口查询四站的最大有效波高和记录数。年度检查按单站查询整年档案，并统计已收到的记录中有多少缺少浪高字段。记录级空值还可能来自传感器报告周期差异，不能据此判断设备故障。

用 Ian 和 Idalia 两次历史过程及对应年份的单站检查选择读取路线，再以 Debby 的 3 个窗口和 2024 年 4 个站的年度检查做留出比较。简报与年度检查的查询比例假定为 3 比 1。所有 Parquet 文件采用 ZSTD 和 8,192 行/组。按月布局由应用根据查询的 UTC 日期先选月文件。

```powershell
.\run.ps1 -Coastal
```

也可在已装好依赖的环境中执行 `python coastal_case.py`。默认生成 [方法对比](coastal-results/methods.csv)、[逐条查询测量](coastal-results/benchmark.csv) 和 [各站浪高结果](coastal-results/wave-reports.csv)。读取字节来自计量文件接口，热缓存耗时来自本地原生路径。文件数、存储和构建耗时对应重放期间生成的布局。

## 固定预算下选站与热点迁移

为 41001、41009、41010、42001 各写一个仅包含本站的 2022–2024 年 Parquet 副本，文件内按观测时间排序。年度检查继续使用同一条查询，分别从按月主档案和单站副本读取，并核对结果一致。副本成本为压缩文件字节数。2022、2023 年每站的平均实测少读字节用于选站，2024 年实测留作评估。

两条规则都枚举四站的 16 个子集，并受同一副本字节上限约束。频次规则最大化覆盖的预计年检次数，读取收益规则最大化各站「预计次数 × 标定单次少读字节」之和。得分相同则选存储更小的组合。两组查询频次均为每 100 次年检的假设情景。对每组频次枚举另外 23 种站点分配，先保持旧组合评估，再允许按新频次重选。推算的读取量用 2024 年各站逐次实测乘假设次数求和，除以总次数即可得到每次均值。

```powershell
.\run.ps1 -HotStations -BudgetMiB 1.5
```

输出 [逐站逐年实测](hot-station-results/audit-measurements.csv)、[副本大小及站点均值](hot-station-results/stations.csv)、[容量扫描](hot-station-results/budget-sweep.csv) 和 [热点迁移重放](hot-station-results/hotspot-shifts.csv)。新选组合的收益沿用同一批实测；迁移场景未计入副本建设和同步成本。

## 按单位副本容量的读取收益选站

在相同的单站 Parquet 实测基础上，增加一条贪心规则。用「预计年检次数 × 标定期单次少读字节 ÷ 副本文件字节」给各站排序，按顺序装入还放得下的副本。对照组仍用穷举，在同一上限下分别最大化覆盖次数和预计总读取节省。

```powershell
.\run.ps1 -HotStations -CompareDensity -BudgetMiB 1.5
```

此模式还会评估 1.39 MiB 的例子，结果单独写入 `replica-efficiency-results/`。容量扫描覆盖从零到全选的各个组合容量临界点。两组假设频次分别在各重点预算下做 23 种热点迁移，保留旧副本和按新频次重选的结果同时列出。[三种规则的容量扫描](replica-efficiency-results/budget-sweep.csv) · [三种规则的热点迁移](replica-efficiency-results/hotspot-shifts.csv)
