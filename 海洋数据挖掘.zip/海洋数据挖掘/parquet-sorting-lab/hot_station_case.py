"""Compare budgeted station replicas under synthetic audit demand and demand shifts."""

import argparse
import itertools
import tempfile
from fractions import Fraction
from pathlib import Path
from statistics import mean

import duckdb

from coastal_case import (
    PARQUET_ORDERS, REGION, ROW_GROUP, build_layouts, csv_scan, reader, requests,
    selected_months, write_csv,
)
from experiment import ROOT, MeteredFiles, build_csv, literal


START_PROFILES = {
    "initial": (37, 31, 23, 9),
    "close_hot_stations": (34, 14, 20, 32),
}
MIB = 1024 ** 2
DENSITY_EXAMPLE_BUDGET = int(Fraction("1.39") * MIB)


def collect_measurements(directory):
    archive_csv = directory / "observations.csv"
    manifest = build_csv(ROOT / "data" / "ndbc", archive_csv)
    with duckdb.connect(config={"threads": 1, "enable_external_file_cache": False}) as db:
        db.execute("LOAD parquet")
        db.execute("SET parquet_metadata_cache = false")
        db.execute("SET preserve_insertion_order = true")
        db.execute(f"""
            CREATE TABLE archive AS
            SELECT row_number() OVER () AS source_row, * FROM {csv_scan(archive_csv)}
        """)
        if db.execute("SELECT COUNT(*) FROM archive").fetchone()[0] != sum(row["rows"] for row in manifest):
            raise RuntimeError("Source record count mismatch")

        layouts, _ = build_layouts(db, directory, archive_csv, {"month_time": PARQUET_ORDERS["month_time"]})
        main = layouts["month_time"]
        replicas = {}
        for station in REGION:
            file = directory / f"replica-{station}.parquet"
            db.execute(f"""
                COPY (SELECT * EXCLUDE (source_row) FROM archive
                      WHERE station_id = {station} ORDER BY obs_time, source_row)
                TO {literal(file)} (FORMAT PARQUET, COMPRESSION ZSTD,
                                    ROW_GROUP_SIZE {ROW_GROUP}, WRITE_BLOOM_FILTER false)
            """)
            replicas[station] = file
        meter = MeteredFiles([*main.values(), *replicas.values()])
        db.register_filesystem(meter)
        measured = []
        for request in requests():
            if request.kind != "audit":
                continue
            station, = request.stations
            year = request.start.year
            expected = db.execute(request.select("archive")).fetchall()
            main_files = [main[month] for month in selected_months(request.start, request.stop)]
            sizes = []
            for files in (main_files, [replicas[station]]):
                meter.bytes_read = 0
                result = db.execute(request.select(reader("parquet", files, True))).fetchall()
                if result != expected or not result or meter.bytes_read <= 0:
                    raise RuntimeError(f"Unexpected result for station {station}, year {year}")
                sizes.append(meter.bytes_read)
            measured.append({
                "station": station, "year": year, "split": request.split,
                "main_read_bytes": sizes[0], "replica_read_bytes": sizes[1],
                "saved_read_bytes": sizes[0] - sizes[1], "matched_records": expected[0][1],
                "valid_wave_records": expected[0][2],
            })
        sizes = {station: file.stat().st_size for station, file in replicas.items()}
        primary_size = sum(file.stat().st_size for file in main.values())
    return measured, sizes, primary_size


def choose(options, sizes, budget, values):
    def score(group):
        return -sum(values[station] for station in group), sum(sizes[station] for station in group), group

    return min((group for group in options if sum(sizes[station] for station in group) <= budget), key=score)


def select_policy(options, sizes, budget, counts, estimates, policy):
    values = counts if policy == "frequency" else {
        station: counts[station] * estimates[station] for station in REGION
    }
    if policy == "read_density":
        stations = sorted(REGION, key=lambda station: (-values[station] / sizes[station], sizes[station], station))
        selected = []
        remaining = budget
        for station in stations:
            if values[station] > 0 and sizes[station] <= remaining:
                selected.append(station)
                remaining -= sizes[station]
        return tuple(sorted(selected))
    return choose(options, sizes, budget, values)


def label(group):
    return "|".join(map(str, group))


def evaluate(measured, sizes, primary_size, budget, compare_density=False):
    options = [
        group for count in range(len(REGION) + 1) for group in itertools.combinations(REGION, count)
    ]
    estimates = {
        station: mean(Fraction(row["saved_read_bytes"]) for row in measured
                      if row["station"] == station and row["split"] == "calibration")
        for station in REGION
    }
    held_out = {row["station"]: row for row in measured if row["split"] == "holdout"}
    actual_savings = {station: row["saved_read_bytes"] for station, row in held_out.items()}
    policies = ("frequency", "read_savings")
    focus_budgets = {budget}
    if compare_density:
        policies = (*policies, "read_density")
        focus_budgets.add(DENSITY_EXAMPLE_BUDGET)

    def predicted(group, counts):
        return sum(counts[station] * estimates[station] for station in group)

    def saved(group, counts):
        return sum(counts[station] * actual_savings[station] for station in group)

    def baseline(counts):
        return sum(counts[station] * held_out[station]["main_read_bytes"] for station in REGION)

    def row_for(group, counts, cap):
        extra = sum(sizes[station] for station in group)
        if extra > cap:
            raise RuntimeError("Infeasible replica selection")
        return {
            "replica_stations": label(group), "budget_bytes": cap,
            "replica_storage_bytes": extra, "total_storage_bytes": primary_size + extra,
            "covered_audit_count": sum(counts[station] for station in group),
            "main_only_read_bytes": baseline(counts),
            "holdout_saved_read_bytes": saved(group, counts),
            "holdout_read_bytes": baseline(counts) - saved(group, counts),
        }

    budgets = sorted(focus_budgets | {sum(sizes[station] for station in group) for group in options})
    sweep = []
    scenarios = []
    for profile_name, starting_counts in START_PROFILES.items():
        before = dict(zip(REGION, starting_counts))
        fixed = {}
        for cap in budgets:
            for policy in policies:
                group = select_policy(options, sizes, cap, before, estimates, policy)
                result = {"profile": profile_name, "policy": policy, **row_for(group, before, cap)}
                if compare_density:
                    result["predicted_saved_read_bytes"] = float(predicted(group, before))
                sweep.append(result)
                if cap in focus_budgets:
                    fixed[cap, policy] = group

        permutations = sorted(set(itertools.permutations(starting_counts)) - {starting_counts})
        for index, permutation in enumerate([starting_counts, *permutations]):
            counts = dict(zip(REGION, permutation))
            actual_values = {station: counts[station] * actual_savings[station] for station in REGION}
            for cap in sorted(focus_budgets):
                ceiling = choose(options, sizes, cap, actual_values)
                for policy in policies:
                    old = fixed[cap, policy]
                    refreshed = select_policy(options, sizes, cap, counts, estimates, policy)
                    original_saved = saved(old, before)
                    scenarios.append({
                        "profile": profile_name, "scenario": "before" if index == 0 else f"shift-{index:02d}",
                        **{f"audits_{station}": count for station, count in counts.items()},
                        "policy": policy,
                        **row_for(old, counts, cap),
                        "fixed_predicted_saved_read_bytes": float(predicted(old, counts)),
                        "fixed_change_saved_read_bytes": saved(old, counts) - original_saved,
                        "fixed_change_read_bytes": baseline(counts) - saved(old, counts)
                            - (baseline(before) - original_saved),
                        "reselected_stations": label(refreshed),
                        "reselected_saved_read_bytes": saved(refreshed, counts),
                        "reselected_read_bytes": baseline(counts) - saved(refreshed, counts),
                        "oracle_stations": label(ceiling),
                        "fixed_regret_bytes": saved(ceiling, counts) - saved(old, counts),
                    })
    stations = [{
        "station": station, "replica_storage_bytes": sizes[station],
        "calibration_mean_saved_read_bytes": float(estimates[station]),
        "holdout_main_read_bytes": held_out[station]["main_read_bytes"],
        "holdout_replica_read_bytes": held_out[station]["replica_read_bytes"],
        "holdout_saved_read_bytes": actual_savings[station],
    } for station in REGION]
    return stations, sweep, scenarios


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--budget-mib", type=float, default=1.5, help="extra replica storage cap")
    parser.add_argument("--compare-density", action="store_true", help="also test density-first selection and the 1.39 MiB case")
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    if not 0 <= args.budget_mib < float("inf"):
        parser.error("budget must be finite and nonnegative")

    with tempfile.TemporaryDirectory(prefix="buoy-station-replicas-") as temp:
        measured, sizes, primary_size = collect_measurements(Path(temp))
    stations, sweep, scenarios = evaluate(
        measured, sizes, primary_size, int(args.budget_mib * MIB), args.compare_density
    )
    default_output = "replica-efficiency-results" if args.compare_density else "hot-station-results"
    output = args.output_dir or ROOT / default_output
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "audit-measurements.csv", measured)
    write_csv(output / "stations.csv", stations)
    write_csv(output / "budget-sweep.csv", sweep)
    write_csv(output / "hotspot-shifts.csv", scenarios)
    print(f"Validated {len(measured)} station-year queries across main and replica. Results: {output}", flush=True)


if __name__ == "__main__":
    main()
